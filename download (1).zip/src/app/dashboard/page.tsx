import { stats } from "@/lib/data";
import { StatCard } from "@/components/stat-card";
import { DiseaseReportsChart, CropDistributionChart } from "@/components/charts";

export default function DashboardPage() {
  return (
    <div className="flex flex-col gap-8">
      <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-4">
        {stats.map((stat) => (
          <StatCard
            key={stat.label}
            icon={stat.icon}
            value={stat.value}
            label={stat.label}
            description={stat.change}
          />
        ))}
      </div>
      <div className="grid gap-4 md:gap-8 lg:grid-cols-2">
        <DiseaseReportsChart />
        <CropDistributionChart />
      </div>
    </div>
  );
}
