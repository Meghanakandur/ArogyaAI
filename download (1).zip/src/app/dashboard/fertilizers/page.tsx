"use client";

import * as React from "react";
import { MoreHorizontal, PlusCircle } from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { fertilizersData } from "@/lib/data";

type Fertilizer = typeof fertilizersData[number];

const fertilizerSchema = z.object({
  name: z.string().min(1, "Name is required"),
  type: z.string().min(1, "Type is required"),
  status: z.enum(["Available", "Low Stock", "Out of Stock"]),
  stock: z.string().min(1, "Stock is required")
});

export default function FertilizersPage() {
  const { toast } = useToast();
  const [fertilizers, setFertilizers] = React.useState(fertilizersData);
  const [isFormOpen, setIsFormOpen] = React.useState(false);
  const [editingFertilizer, setEditingFertilizer] = React.useState<Fertilizer | null>(null);

  const form = useForm<z.infer<typeof fertilizerSchema>>({
    resolver: zodResolver(fertilizerSchema),
    defaultValues: {
      name: "",
      type: "",
      status: "Available",
      stock: "",
    },
  });

  React.useEffect(() => {
    if (editingFertilizer) {
      form.reset(editingFertilizer);
    } else {
      form.reset({
        name: "",
        type: "",
        status: "Available",
        stock: "",
      });
    }
  }, [editingFertilizer, form]);

  const handleDialogOpen = (fertilizer: Fertilizer | null) => {
    setEditingFertilizer(fertilizer);
    setIsFormOpen(true);
  };

  const handleDelete = (id: string) => {
    setFertilizers(fertilizers.filter((f) => f.id !== id));
    toast({
      title: "Fertilizer Deleted",
      description: "The fertilizer has been successfully deleted.",
    });
  };

  const onSubmit = (values: z.infer<typeof fertilizerSchema>) => {
    if (editingFertilizer) {
      setFertilizers(
        fertilizers.map((f) =>
          f.id === editingFertilizer.id ? { ...f, ...values } : f
        )
      );
      toast({
        title: "Fertilizer Updated",
        description: "The fertilizer has been successfully updated.",
      });
    } else {
      const newFertilizer = {
        id: `FERT${String(fertilizers.length + 1).padStart(3, '0')}`,
        ...values,
      };
      setFertilizers([newFertilizer, ...fertilizers]);
      toast({
        title: "Fertilizer Added",
        description: "A new fertilizer has been successfully added.",
      });
    }
    setIsFormOpen(false);
    setEditingFertilizer(null);
  };

  const getStatusBadgeVariant = (status: Fertilizer['status']) => {
    switch (status) {
      case 'Available':
        return 'default';
      case 'Low Stock':
        return 'secondary';
      case 'Out of Stock':
        return 'destructive';
      default:
        return 'outline';
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
            <div>
                <CardTitle>Fertilizers</CardTitle>
                <CardDescription>
                    Manage fertilizer inventory and details.
                </CardDescription>
            </div>
            <Button size="sm" className="gap-1" onClick={() => handleDialogOpen(null)}>
                <PlusCircle className="h-3.5 w-3.5" />
                <span className="sr-only sm:not-sr-only sm:whitespace-nowrap">
                Add Fertilizer
                </span>
            </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead className="hidden md:table-cell">Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="hidden md:table-cell">Stock</TableHead>
              <TableHead>
                <span className="sr-only">Actions</span>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {fertilizers.map((fertilizer) => (
              <TableRow key={fertilizer.id}>
                <TableCell className="font-medium">{fertilizer.name}</TableCell>
                <TableCell className="hidden md:table-cell">{fertilizer.type}</TableCell>
                <TableCell>
                  <Badge variant={getStatusBadgeVariant(fertilizer.status)}>
                    {fertilizer.status}
                  </Badge>
                </TableCell>
                <TableCell className="hidden md:table-cell">{fertilizer.stock}</TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button aria-haspopup="true" size="icon" variant="ghost">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Toggle menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuItem onSelect={() => handleDialogOpen(fertilizer)}>
                        Edit
                      </DropdownMenuItem>
                       <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <DropdownMenuItem onSelect={(e) => e.preventDefault()}>Delete</DropdownMenuItem>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This action will permanently delete the fertilizer record.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDelete(fertilizer.id)} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>

      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{editingFertilizer ? "Edit Fertilizer" : "Add Fertilizer"}</DialogTitle>
            <DialogDescription>
                {editingFertilizer ? "Update the details of the fertilizer." : "Add a new fertilizer to the system."}
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 py-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Type</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g., Nitrogen, Phosphate" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="stock"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Stock</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g., 5000 tons"/>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Available">Available</SelectItem>
                        <SelectItem value="Low Stock">Low Stock</SelectItem>
                        <SelectItem value="Out of Stock">Out of Stock</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsFormOpen(false)}>Cancel</Button>
                <Button type="submit">Save</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
