import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { modelsData } from "@/lib/data";

export default function ModelsPage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>AI Model Management</CardTitle>
        <CardDescription>
          View and manage the AI models in production.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[200px]">Model ID</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="hidden md:table-cell">Last Updated</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {modelsData.map((model) => (
              <TableRow key={model.id}>
                <TableCell className="font-medium">{model.name}</TableCell>
                <TableCell>{model.type}</TableCell>
                <TableCell>
                  <Badge variant={model.status === "Active" ? "default" : "outline"} className={model.status === "Active" ? "" : "bg-muted text-muted-foreground"}>
                    {model.status}
                  </Badge>
                </TableCell>
                <TableCell className="hidden md:table-cell">
                  {model.lastUpdated}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
