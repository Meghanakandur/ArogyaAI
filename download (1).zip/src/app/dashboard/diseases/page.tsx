"use client";

import * as React from "react";
import { MoreHorizontal, PlusCircle } from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { diseasesData, cropsData } from "@/lib/data";
import { BlockchainBadge } from "@/components/blockchain-badge";

type Disease = typeof diseasesData[number];

const diseaseSchema = z.object({
  name: z.string().min(1, "Name is required"),
  crop: z.string().min(1, "Associated crop is required"),
  status: z.enum(["Active", "Inactive"]),
  verifiedOnChain: z.boolean(),
});

export default function DiseasesPage() {
  const { toast } = useToast();
  const [diseases, setDiseases] = React.useState(diseasesData);
  const [isFormOpen, setIsFormOpen] = React.useState(false);
  const [editingDisease, setEditingDisease] = React.useState<Disease | null>(null);

  const form = useForm<z.infer<typeof diseaseSchema>>({
    resolver: zodResolver(diseaseSchema),
    defaultValues: {
      name: "",
      crop: "",
      status: "Active",
      verifiedOnChain: false,
    },
  });

  React.useEffect(() => {
    if (editingDisease) {
      form.reset(editingDisease);
    } else {
      form.reset({
        name: "",
        crop: "",
        status: "Active",
        verifiedOnChain: false,
      });
    }
  }, [editingDisease, form]);

  const handleDialogOpen = (disease: Disease | null) => {
    setEditingDisease(disease);
    setIsFormOpen(true);
  };

  const handleDelete = (id: string) => {
    setDiseases(diseases.filter((disease) => disease.id !== id));
    toast({
      title: "Disease Deleted",
      description: "The disease has been successfully deleted.",
      variant: "destructive"
    });
  };

  const onSubmit = (values: z.infer<typeof diseaseSchema>) => {
    if (editingDisease) {
      setDiseases(
        diseases.map((d) =>
          d.id === editingDisease.id ? { ...d, ...values, lastUpdated: new Date().toISOString().split('T')[0] } : d
        )
      );
      toast({
        title: "Disease Updated",
        description: "The disease has been successfully updated.",
      });
    } else {
      const newDisease = {
        id: `DIS${String(diseases.length + 1).padStart(3, '0')}`,
        ...values,
        lastUpdated: new Date().toISOString().split('T')[0]
      };
      setDiseases([newDisease, ...diseases]);
      toast({
        title: "Disease Added",
        description: "A new disease has been successfully added.",
      });
    }
    setIsFormOpen(false);
    setEditingDisease(null);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
            <div>
                <CardTitle>Diseases</CardTitle>
                <CardDescription>
                    Manage crop diseases and their verification status.
                </CardDescription>
            </div>
            <Button size="sm" className="gap-1" onClick={() => handleDialogOpen(null)}>
                <PlusCircle className="h-3.5 w-3.5" />
                <span className="sr-only sm:not-sr-only sm:whitespace-nowrap">
                Add Disease
                </span>
            </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead className="hidden md:table-cell">Crop</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="hidden md:table-cell">Last Updated</TableHead>
              <TableHead>
                <span className="sr-only">Actions</span>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {diseases.map((disease) => (
              <TableRow key={disease.id}>
                <TableCell className="font-medium flex items-center gap-2">
                    {disease.name}
                    <BlockchainBadge verified={disease.verifiedOnChain} />
                </TableCell>
                <TableCell className="hidden md:table-cell">{disease.crop}</TableCell>
                <TableCell>
                  <Badge variant={disease.status === "Active" ? "default" : "outline"} className={disease.status === "Active" ? "" : "bg-muted text-muted-foreground"}>
                    {disease.status}
                  </Badge>
                </TableCell>
                <TableCell className="hidden md:table-cell">{disease.lastUpdated}</TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button aria-haspopup="true" size="icon" variant="ghost">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Toggle menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuItem onSelect={() => handleDialogOpen(disease)}>
                        Edit
                      </DropdownMenuItem>
                       <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-600">Delete</DropdownMenuItem>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the disease record.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDelete(disease.id)} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>

      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{editingDisease ? "Edit Disease" : "Add Disease"}</DialogTitle>
            <DialogDescription>
                {editingDisease ? "Update the details of the disease." : "Add a new disease to the system."}
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 py-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="crop"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Associated Crop</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                            <SelectTrigger>
                            <SelectValue placeholder="Select a crop" />
                            </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                            {cropsData.map(crop => <SelectItem key={crop.id} value={crop.name}>{crop.name}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Active">Active</SelectItem>
                        <SelectItem value="Inactive">Inactive</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="verifiedOnChain"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>Verified on Blockchain</FormLabel>
                       <FormMessage />
                    </div>
                    <FormControl>
                       <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
               <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsFormOpen(false)}>Cancel</Button>
                <Button type="submit">Save</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
