'use server';

import { Aptos, AptosConfig, Network } from "@aptos-labs/ts-sdk";

// Setup the client
const aptosConfig = new AptosConfig({ network: Network.TESTNET });
const aptos = new Aptos(aptosConfig);

const MODULE_ADDRESS = "0x9c31b7544b802a1e367809a8a3a08b9a2b5af3c6f49e0544c4a3f36c53e34b5c";

/**
 * Fetches farmer data from the Aptos blockchain.
 * @param farmerId The Aptos account address of the farmer.
 * @returns The farmer's data stored on-chain.
 */
export async function getAptosFarmerData(farmerId: string): Promise<any> {
  try {
    const farmerData = await aptos.getAccountResource({
        accountAddress: farmerId,
        resourceType: `${MODULE_ADDRESS}::farmer_profile::FarmerProfile`,
    });
    return farmerData;
  } catch (error: any) {
    // If the resource is not found, it might mean the farmer hasn't created a profile yet.
    if (error.status === 404) {
        return { message: `No FarmerProfile found for address ${farmerId}. The user may need to create one.` };
    }
    console.error("Error fetching data from Aptos:", error);
    throw new Error(`Could not fetch data from Aptos for farmer ${farmerId}.`);
  }
}
