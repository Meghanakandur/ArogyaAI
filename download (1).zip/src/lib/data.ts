import { Carrot, Bug, FlaskConical, Cpu, Users, Leaf, ShieldCheck, LayoutDashboard } from "lucide-react";

export const stats = [
  {
    icon: Users,
    value: "1,254",
    label: "Active Farmers",
    change: "+15.2% from last month",
  },
  {
    icon: Leaf,
    value: "38",
    label: "Crops Managed",
    change: "+5 new crops added",
  },
  {
    icon: Bug,
    value: "1,892",
    label: "Detections this week",
    change: "-8.5% from last week",
  },
  {
    icon: ShieldCheck,
    value: "2,341",
    label: "Verified Records",
    change: "Total on-chain records",
  },
];

export const analyticsData = {
  diseaseReports: [
    { month: "Jan", reports: 186 },
    { month: "Feb", reports: 305 },
    { month: "Mar", reports: 237 },
    { month: "Apr", reports: 173 },
    { month: "May", reports: 209 },
    { month: "Jun", reports: 280 },
    { month: "Jul", reports: 310 },
  ],
  cropDistribution: [
    { name: "Wheat", value: 400, fill: "hsl(var(--chart-1))" },
    { name: "Rice", value: 300, fill: "hsl(var(--chart-2))" },
    { name: "Corn", value: 250, fill: "hsl(var(--chart-3))" },
    { name: "Tomato", value: 200, fill: "hsl(var(--chart-4))" },
    { name: "Potato", value: 150, fill: "hsl(var(--chart-5))" },
  ],
};

export const cropsData = [
  { id: "CROP001", name: "Tomato", scientificName: "Solanum lycopersicum", status: "Active", lastUpdated: "2023-10-27" },
  { id: "CROP002", name: "Wheat", scientificName: "Triticum aestivum", status: "Active", lastUpdated: "2023-10-25" },
  { id: "CROP003", name: "Rice", scientificName: "Oryza sativa", status: "Active", lastUpdated: "2023-10-22" },
  { id: "CROP004", name: "Corn", scientificName: "Zea mays", status: "Inactive", lastUpdated: "2023-09-15" },
  { id: "CROP005", name: "Potato", scientificName: "Solanum tuberosum", status: "Active", lastUpdated: "2023-10-28" },
];

export const diseasesData = [
  { id: "DIS001", name: "Late Blight", crop: "Tomato", status: "Active", lastUpdated: "2023-10-26", verifiedOnChain: true },
  { id: "DIS002", name: "Powdery Mildew", crop: "Wheat", status: "Active", lastUpdated: "2023-10-24", verifiedOnChain: true },
  { id: "DIS003", name: "Rust", crop: "Wheat", status: "Inactive", lastUpdated: "2023-09-30", verifiedOnChain: false },
  { id: "DIS004", name: "Blast", crop: "Rice", status: "Active", lastUpdated: "2023-10-21", verifiedOnChain: true },
  { id: "DIS005", name: "Common Scab", crop: "Potato", status: "Active", lastUpdated: "2023-10-28", verifiedOnChain: false },
];

export const fertilizersData = [
    { id: "FERT001", name: "Urea", type: "Nitrogen", status: "Available", stock: "5000 tons" },
    { id: "FERT002", name: "DAP", type: "Phosphate", status: "Available", stock: "3500 tons" },
    { id: "FERT003", name: "MOP", type: "Potash", status: "Low Stock", stock: "800 tons" },
    { id: "FERT004", name: "NPK 10-26-26", type: "Complex", status: "Available", stock: "6000 tons" },
    { id: "FERT005", name: "Gypsum", type: "Sulphur", status: "Out of Stock", stock: "0 tons" },
];

export const modelsData = [
  { id: "MOD001", name: "CropDisease-CNN-v3.2", type: "Disease Detection", status: "Active", lastUpdated: "2023-10-15" },
  { id: "MOD002", name: "SoilPredict-RF-v1.5", type: "Soil Prediction", status: "Active", lastUpdated: "2023-09-20" },
  { id: "MOD003", name: "FertilizerRec-GB-v2.1", type: "Recommendation", status: "Active", lastUpdated: "2023-10-05" },
  { id: "MOD004", name: "CropDisease-CNN-v3.1", type: "Disease Detection", status: "Inactive", lastUpdated: "2023-08-01" },
];

export const navItems = [
    { href: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { href: "/dashboard/crops", icon: Carrot, label: "Crops" },
    { href: "/dashboard/diseases", icon: Bug, label: "Diseases" },
    { href: "/dashboard/fertilizers", icon: FlaskConical, label: "Fertilizers" },
    { href: "/dashboard/models", icon: Cpu, label: "Models" },
];
