"use client";

import { Bar, BarChart, CartesianGrid, XAxis, Line, LineChart, ResponsiveContainer, Tooltip as RechartsTooltip } from "recharts";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import { analyticsData } from "@/lib/data";

const diseaseReportsChartConfig = {
  reports: {
    label: "Reports",
  },
};

const cropDistributionChartConfig = {
  value: {
    label: "Count",
  },
  name: {
    label: "Crop",
  },
};

export function DiseaseReportsChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Disease Reports Overview</CardTitle>
        <CardDescription>January - July 2023</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={diseaseReportsChartConfig} className="h-[250px] w-full">
          <LineChart data={analyticsData.diseaseReports}>
            <CartesianGrid vertical={false} />
            <XAxis
              dataKey="month"
              tickLine={false}
              axisLine={false}
              tickMargin={8}
            />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Line
              dataKey="reports"
              type="monotone"
              stroke="hsl(var(--primary))"
              strokeWidth={2}
              dot={{ fill: "hsl(var(--primary))" }}
              activeDot={{ r: 6 }}
            />
          </LineChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}

export function CropDistributionChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Crop Distribution</CardTitle>
        <CardDescription>Distribution of major crops managed</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={cropDistributionChartConfig} className="h-[250px] w-full">
          <BarChart data={analyticsData.cropDistribution} accessibilityLayer>
            <CartesianGrid vertical={false} />
            <XAxis
              dataKey="name"
              tickLine={false}
              tickMargin={10}
              axisLine={false}
            />
            <ChartTooltip
              cursor={false}
              content={<ChartTooltipContent indicator="dot" />}
            />
            <Bar dataKey="value" radius={8} />
          </BarChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
