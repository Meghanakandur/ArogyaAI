import { ShieldCheck } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface BlockchainBadgeProps {
  verified: boolean;
  className?: string;
}

export function BlockchainBadge({ verified, className }: BlockchainBadgeProps) {
  if (!verified) {
    return null;
  }

  return (
    <Badge variant="secondary" className={cn("gap-1.5", className)}>
      <ShieldCheck className="h-3.5 w-3.5 text-primary" />
      Verified
    </Badge>
  );
}
