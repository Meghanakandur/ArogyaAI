import { config } from 'dotenv';
config();

import '@/ai/flows/ai-soil-prediction.ts';
import '@/ai/flows/ai-disease-detection.ts';
import '@/ai/flows/disease-detection-tool-in-chatbot.ts';
import '@/ai/flows/ai-smart-fertilizer-recommendation.ts';
import '@/ai/flows/ai-agriculture-chatbot.ts';
import '@/ai/flows/weather-fetch-tool-in-chatbot.ts';
import '@/ai/flows/aptos-data-fetcher-tool-in-chatbot.ts';
import '@/ai/flows/soil-predictor-tool-in-chatbot.ts';
import '@/ai/flows/market-price-fetch-tool-in-chatbot.ts';