'use server';
/**
 * @fileOverview AI tool to predict soil type and nutrients from within the AI chatbot.
 *
 * - getSoilPrediction - A function that handles the soil prediction process.
 * - SoilPredictionInput - The input type for the getSoilPrediction function.
 * - SoilPredictionOutput - The return type for the getSoilPrediction function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SoilPredictionInputSchema = z.object({
  gpsCoordinates: z
    .string()
    .describe('GPS coordinates of the soil sample location.'),
  soilImageUri: z
    .string()
    .describe(
      "A photo of the soil, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  npkValues: z
    .string()
    .optional()
    .describe('Optional NPK values (Nitrogen, Phosphorus, Potassium) for the soil sample.'),
});
export type SoilPredictionInput = z.infer<typeof SoilPredictionInputSchema>;

const SoilPredictionOutputSchema = z.object({
  soilType: z.string().describe('The predicted soil type.'),
  moistureLevel: z.string().describe('The predicted moisture level of the soil.'),
  nutrientDeficiencies: z
    .string()
    .describe('The predicted nutrient deficiencies in the soil.'),
});
export type SoilPredictionOutput = z.infer<typeof SoilPredictionOutputSchema>;

export async function getSoilPrediction(input: SoilPredictionInput): Promise<SoilPredictionOutput> {
  return soilPredictionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'soilPredictionPrompt',
  input: {schema: SoilPredictionInputSchema},
  output: {schema: SoilPredictionOutputSchema},
  prompt: `You are an expert soil analyst. You will analyze the provided information to predict the soil type, moisture level, and any nutrient deficiencies.

GPS Coordinates: {{{gpsCoordinates}}}
Soil Image: {{media url=soilImageUri}}
NPK Values (optional): {{{npkValues}}}

Provide your analysis and predictions based on the above information.`,
});

const soilPredictionFlow = ai.defineFlow(
  {
    name: 'soilPredictionFlow',
    inputSchema: SoilPredictionInputSchema,
    outputSchema: SoilPredictionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
