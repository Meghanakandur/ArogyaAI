'use server';
/**
 * @fileOverview AI crop disease detection tool for the AI chatbot.
 *
 * - diseaseDetectionToolInChatbot - A function that handles the plant disease detection process from within the chatbot.
 * - DiseaseDetectionToolInChatbotInput - The input type for the diseaseDetectionToolInChatbot function.
 * - DiseaseDetectionToolInChatbotOutput - The return type for the diseaseDetectionToolInChatbot function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const DiseaseDetectionToolInChatbotInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "A photo of a plant, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  description: z.string().describe('The description of the plant.'),
});
export type DiseaseDetectionToolInChatbotInput = z.infer<typeof DiseaseDetectionToolInChatbotInputSchema>;

const DiseaseDetectionToolInChatbotOutputSchema = z.object({
  diseaseName: z.string().describe('The predicted name of the disease.'),
  confidence: z.number().describe('The confidence level of the prediction (0-1).'),
  cureSteps: z.string().describe('Steps to cure the disease.'),
});
export type DiseaseDetectionToolInChatbotOutput = z.infer<typeof DiseaseDetectionToolInChatbotOutputSchema>;

export async function diseaseDetectionToolInChatbot(input: DiseaseDetectionToolInChatbotInput): Promise<DiseaseDetectionToolInChatbotOutput> {
  return diseaseDetectionToolInChatbotFlow(input);
}

const prompt = ai.definePrompt({
  name: 'diseaseDetectionToolInChatbotPrompt',
  input: {schema: DiseaseDetectionToolInChatbotInputSchema},
  output: {schema: DiseaseDetectionToolInChatbotOutputSchema},
  prompt: `You are an expert in identifying plant diseases.
  Based on the photo and description provided, identify the disease, the confidence level (0-1), and steps to cure it.
  Description: {{{description}}}
  Photo: {{media url=photoDataUri}}`,
});

const diseaseDetectionToolInChatbotFlow = ai.defineFlow(
  {
    name: 'diseaseDetectionToolInChatbotFlow',
    inputSchema: DiseaseDetectionToolInChatbotInputSchema,
    outputSchema: DiseaseDetectionToolInChatbotOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
