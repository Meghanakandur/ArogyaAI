'use server';

/**
 * @fileOverview AI Agriculture Chatbot flow.
 *
 * - aiAgricultureChatbot - A function that handles the AI Agriculture Chatbot process.
 * - AiAgricultureChatbotInput - The input type for the aiAgricultureChatbot function.
 * - AiAgricultureChatbotOutput - The return type for the aiAgricultureChatbot function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import { getAptosFarmerData } from '@/services/aptos';

const AiAgricultureChatbotInputSchema = z.object({
  query: z.string().describe('The user query about crops, soil, fertilizers, government schemes, and diseases.'),
});
export type AiAgricultureChatbotInput = z.infer<typeof AiAgricultureChatbotInputSchema>;

const AiAgricultureChatbotOutputSchema = z.object({
  answer: z.string().describe('The answer to the user query.'),
});
export type AiAgricultureChatbotOutput = z.infer<typeof AiAgricultureChatbotOutputSchema>;

export async function aiAgricultureChatbot(input: AiAgricultureChatbotInput): Promise<AiAgricultureChatbotOutput> {
  return aiAgricultureChatbotFlow(input);
}

const diseaseDetectionTool = ai.defineTool({
  name: 'diseaseDetectionTool',
  description: 'Detects diseases from plant images.',
  inputSchema: z.object({
    photoDataUri: z
      .string()
      .describe(
        "A photo of a plant, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
      ),
  }),
  outputSchema: z.string(),
}, async (input) => {
  // Placeholder implementation - replace with actual disease detection logic
  return `Disease detection results for the provided image: [PLACEHOLDER - IMPLEMENT DISEASE DETECTION HERE]`;
});

const soilPredictorTool = ai.defineTool({
  name: 'soilPredictorTool',
  description: 'Predicts soil type and nutrients based on GPS, soil image, and NPK values.',
  inputSchema: z.object({
    gps: z.string().optional().describe('GPS coordinates.'),
    soilPhotoDataUri: z.string().optional().describe(
      "A photo of the soil, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
    npkValues: z.string().optional().describe('Optional NPK values.'),
  }),
  outputSchema: z.string(),
}, async (input) => {
  // Placeholder implementation - replace with actual soil prediction logic
  return `Soil prediction results: [PLACEHOLDER - IMPLEMENT SOIL PREDICTION HERE]`;
});

const weatherFetchTool = ai.defineTool({
  name: 'weatherFetchTool',
  description: 'Fetches current weather conditions.',
  inputSchema: z.object({
    location: z.string().describe('The location to fetch weather for.'),
  }),
  outputSchema: z.string(),
}, async (input) => {
  // Placeholder implementation - replace with actual weather fetching logic
  return `Weather conditions for ${input.location}: [PLACEHOLDER - IMPLEMENT WEATHER FETCHING HERE]`;
});

const marketPriceFetchTool = ai.defineTool({
  name: 'marketPriceFetchTool',
  description: 'Fetches current market prices for crops.',
  inputSchema: z.object({
    crop: z.string().describe('The crop to fetch market prices for.'),
  }),
  outputSchema: z.string(),
}, async (input) => {
  // Placeholder implementation - replace with actual market price fetching logic
  return `Market prices for ${input.crop}: [PLACEHOLDER - IMPLEMENT MARKET PRICE FETCHING HERE]`;
});

const aptosDataFetcherTool = ai.defineTool({
  name: 'aptosDataFetcherTool',
  description: 'Fetches blockchain-verified agricultural data from the Aptos testnet for a given farmer ID.',
  inputSchema: z.object({
    farmerId: z.string().describe('The ID of the farmer, which is an Aptos account address.'),
  }),
  outputSchema: z.string(),
}, async (input) => {
  console.log(`Fetching Aptos data for farmer: ${input.farmerId}`);
  try {
    const data = await getAptosFarmerData(input.farmerId);
    return JSON.stringify(data, null, 2);
  } catch (error: any) {
    console.error(`Error fetching Aptos data: ${error.message}`);
    return `Failed to fetch data from Aptos. Error: ${error.message}`;
  }
});

const prompt = ai.definePrompt({
  name: 'aiAgricultureChatbotPrompt',
  input: {schema: AiAgricultureChatbotInputSchema},
  output: {schema: AiAgricultureChatbotOutputSchema},
  tools: [diseaseDetectionTool, soilPredictorTool, weatherFetchTool, marketPriceFetchTool, aptosDataFetcherTool],
  prompt: `You are a helpful AI Agriculture Chatbot. Answer the following question to the best of your ability, using the available tools when appropriate. If you use the aptosDataFetcherTool, make sure to inform the user that the data is coming from the Aptos blockchain.\n\nQuestion: {{{query}}}`,
});

const aiAgricultureChatbotFlow = ai.defineFlow(
  {
    name: 'aiAgricultureChatbotFlow',
    inputSchema: AiAgricultureChatbotInputSchema,
    outputSchema: AiAgricultureChatbotOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
