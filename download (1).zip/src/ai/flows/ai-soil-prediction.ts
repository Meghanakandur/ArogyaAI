'use server';

/**
 * @fileOverview An AI agent for predicting soil type, moisture, and nutrient deficiencies.
 *
 * - predictSoil - A function that handles the soil prediction process.
 * - PredictSoilInput - The input type for the predictSoil function.
 * - PredictSoilOutput - The return type for the predictSoil function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PredictSoilInputSchema = z.object({
  location: z
    .string()
    .describe('The GPS coordinates of the soil sample (e.g., \'37.7749,-122.4194\').'),
  soilImageDataUri: z
    .string()
    .optional()
    .describe(
      "A photo of the soil, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  npkValues: z
    .string()
    .optional()
    .describe('Optional NPK values (Nitrogen, Phosphorus, Potassium) for the soil sample.'),
});
export type PredictSoilInput = z.infer<typeof PredictSoilInputSchema>;

const PredictSoilOutputSchema = z.object({
  soilType: z.string().describe('The predicted soil type (e.g., sandy, clay, loam).'),
  moisture: z
    .string()
    .describe('The predicted soil moisture level (e.g., dry, moist, saturated).'),
  nutrientDeficiencies: z
    .string()
    .describe('Any predicted nutrient deficiencies in the soil (e.g., Nitrogen deficiency).'),
});
export type PredictSoilOutput = z.infer<typeof PredictSoilOutputSchema>;

export async function predictSoil(input: PredictSoilInput): Promise<PredictSoilOutput> {
  return predictSoilFlow(input);
}

const prompt = ai.definePrompt({
  name: 'predictSoilPrompt',
  input: {schema: PredictSoilInputSchema},
  output: {schema: PredictSoilOutputSchema},
  prompt: `You are an expert soil analyst. Given the following information, predict the soil type, moisture, and any nutrient deficiencies.

Location: {{{location}}}

{{#if soilImageDataUri}}
Soil Image: {{media url=soilImageDataUri}}
{{/if}}

{{#if npkValues}}
NPK Values: {{{npkValues}}}
{{/if}}

Provide your analysis in a structured format.`,
});

const predictSoilFlow = ai.defineFlow(
  {
    name: 'predictSoilFlow',
    inputSchema: PredictSoilInputSchema,
    outputSchema: PredictSoilOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
