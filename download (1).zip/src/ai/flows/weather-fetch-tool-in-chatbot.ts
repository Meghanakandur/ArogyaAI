'use server';
/**
 * @fileOverview A tool to fetch weather information for the AI chatbot.
 *
 * - fetchWeather - A function that handles fetching weather information.
 * - FetchWeatherInput - The input type for the fetchWeather function.
 * - FetchWeatherOutput - The return type for the fetchWeather function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const FetchWeatherInputSchema = z.object({
  location: z
    .string()
    .describe('The location for which to fetch weather information.'),
});
export type FetchWeatherInput = z.infer<typeof FetchWeatherInputSchema>;

const FetchWeatherOutputSchema = z.object({
  weatherDescription: z
    .string()
    .describe('A description of the current weather conditions.'),
  temperatureCelsius: z.number().describe('The current temperature in Celsius.'),
});
export type FetchWeatherOutput = z.infer<typeof FetchWeatherOutputSchema>;

export async function fetchWeather(input: FetchWeatherInput): Promise<FetchWeatherOutput> {
  return fetchWeatherFlow(input);
}

const fetchWeatherPrompt = ai.definePrompt({
  name: 'fetchWeatherPrompt',
  input: {schema: FetchWeatherInputSchema},
  output: {schema: FetchWeatherOutputSchema},
  prompt: `You are a helpful weather information provider.

  Provide a concise description of the weather and the current temperature in Celsius for the given location.

  Location: {{{location}}}`,
});

const fetchWeatherFlow = ai.defineFlow(
  {
    name: 'fetchWeatherFlow',
    inputSchema: FetchWeatherInputSchema,
    outputSchema: FetchWeatherOutputSchema,
  },
  async input => {
    const {output} = await fetchWeatherPrompt(input);
    return output!;
  }
);
