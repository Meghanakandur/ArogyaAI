'use server';
/**
 * @fileOverview A smart fertilizer recommendation AI agent.
 *
 * - recommendFertilizer - A function that provides fertilizer recommendations.
 * - RecommendFertilizerInput - The input type for the recommendFertilizer function.
 * - RecommendFertilizerOutput - The return type for the recommendFertilizer function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const RecommendFertilizerInputSchema = z.object({
  crop: z.string().describe('The type of crop being grown.'),
  soilType: z.string().describe('The type of soil the crop is planted in.'),
  soilMoisture: z.string().describe('The moisture content of the soil.'),
  npkValues: z
    .string()
    .optional()
    .describe('Optional NPK (Nitrogen, Phosphorus, Potassium) values of the soil.'),
  weatherConditions: z.string().describe('The current weather conditions.'),
});
export type RecommendFertilizerInput = z.infer<typeof RecommendFertilizerInputSchema>;

const RecommendFertilizerOutputSchema = z.object({
  recommendation: z
    .string()
    .describe('A personalized fertilizer recommendation based on the input parameters.'),
  reasoning: z
    .string()
    .describe('The reasoning behind the fertilizer recommendation, explaining why it is suitable.'),
});
export type RecommendFertilizerOutput = z.infer<typeof RecommendFertilizerOutputSchema>;

export async function recommendFertilizer(input: RecommendFertilizerInput): Promise<RecommendFertilizerOutput> {
  return recommendFertilizerFlow(input);
}

const prompt = ai.definePrompt({
  name: 'recommendFertilizerPrompt',
  input: {schema: RecommendFertilizerInputSchema},
  output: {schema: RecommendFertilizerOutputSchema},
  prompt: `You are an expert in agricultural science, specializing in fertilizer recommendations.

  Based on the provided crop type, soil conditions, and weather, provide a personalized fertilizer recommendation.
  Explain the reasoning behind your recommendation, ensuring it is easy for farmers to understand.

  Crop Type: {{{crop}}}
  Soil Type: {{{soilType}}}
  Soil Moisture: {{{soilMoisture}}}
  NPK Values (if available): {{{npkValues}}}
  Weather Conditions: {{{weatherConditions}}}

  Recommendation:
  `, // End of Prompt
});

const recommendFertilizerFlow = ai.defineFlow(
  {
    name: 'recommendFertilizerFlow',
    inputSchema: RecommendFertilizerInputSchema,
    outputSchema: RecommendFertilizerOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
