'use server';
/**
 * @fileOverview This file defines the MarketPriceFetchToolInChatbot flow, which allows a farmer to fetch market prices using the AI chatbot.
 *
 * The flow takes a query as input and returns the market price information.
 *
 * @remarks
 * Input type: string (query)
 * Output type: string (market price information)
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const MarketPriceFetchToolInputSchema = z.string().describe('The query for market prices.');
export type MarketPriceFetchToolInput = z.infer<typeof MarketPriceFetchToolInputSchema>;

const MarketPriceFetchToolOutputSchema = z.string().describe('The market price information.');
export type MarketPriceFetchToolOutput = z.infer<typeof MarketPriceFetchToolOutputSchema>;

export async function fetchMarketPrice(input: MarketPriceFetchToolInput): Promise<MarketPriceFetchToolOutput> {
  return fetchMarketPriceFlow(input);
}

const prompt = ai.definePrompt({
  name: 'marketPriceFetchPrompt',
  input: {schema: MarketPriceFetchToolInputSchema},
  output: {schema: MarketPriceFetchToolOutputSchema},
  prompt: `You are a helpful assistant for farmers.  The farmer is asking for market prices.  Return the current market price for the following query: {{{$input}}}`,
});

const fetchMarketPriceFlow = ai.defineFlow(
  {
    name: 'fetchMarketPriceFlow',
    inputSchema: MarketPriceFetchToolInputSchema,
    outputSchema: MarketPriceFetchToolOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
